import { useState } from "react";
import { Wind, Factory, Leaf, TrendingDown, Zap, Activity } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import StatCard from "@/components/StatCard";
import EmissionsChart from "@/components/EmissionsChart";
import AirQualityChart from "@/components/AirQualityChart";
import SimulationPanel from "@/components/SimulationPanel";
import UrbanMap from "@/components/UrbanMap";
import { cities } from "@/data/cityData";

const Index = () => {
  const [selectedCity, setSelectedCity] = useState(0);
  const city = cities[selectedCity];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border px-6 py-4">
        <div className="mx-auto flex max-w-7xl items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="rounded-lg gradient-green p-2">
              <Wind className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground">CarbonTwin</h1>
              <p className="text-xs text-muted-foreground">Digital Twin for CO₂ Capture in Urban Settings</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Select value={String(selectedCity)} onValueChange={(v) => setSelectedCity(Number(v))}>
              <SelectTrigger className="w-[180px] border-border bg-card text-foreground">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {cities.map((c, i) => (
                  <SelectItem key={c.name} value={String(i)}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1.5">
              <Activity className="h-3 w-3 text-primary" />
              <span className="text-xs font-medium text-primary">Live Simulation</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-7xl p-6">
        {/* Stats */}
        <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Total CO₂ Emissions"
            value={city.stats.totalEmissions.value}
            unit="kt/yr"
            change={city.stats.totalEmissions.change}
            changeType={city.stats.totalEmissions.changeType}
            icon={Factory}
          />
          <StatCard
            title="Carbon Captured"
            value={city.stats.carbonCaptured.value}
            unit="kt/yr"
            change={city.stats.carbonCaptured.change}
            changeType={city.stats.carbonCaptured.changeType}
            icon={Leaf}
          />
          <StatCard
            title="Net Reduction"
            value={city.stats.netReduction.value}
            unit="%"
            change={city.stats.netReduction.change}
            changeType={city.stats.netReduction.changeType}
            icon={TrendingDown}
          />
          <StatCard
            title="Energy Efficiency"
            value={city.stats.energyEfficiency.value}
            unit="score"
            change={city.stats.energyEfficiency.change}
            changeType={city.stats.energyEfficiency.changeType}
            icon={Zap}
          />
        </div>

        {/* Charts & Controls */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <EmissionsChart data={city.emissions} />
            <AirQualityChart data={city.aqi} />
          </div>
          <div className="space-y-6">
            <SimulationPanel />
            <UrbanMap zones={city.zones} cityName={city.name} />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Index;
