import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";

interface EmissionsChartProps {
  data: { sector: string; current: number; withCapture: number }[];
}

const EmissionsChart = ({ data }: EmissionsChartProps) => (
  <div className="rounded-xl border border-border bg-card p-5">
    <h3 className="mb-1 text-sm font-semibold text-foreground">Emissions by Sector</h3>
    <p className="mb-4 text-xs text-muted-foreground">Current vs. with carbon capture (kt CO₂/yr)</p>
    <ResponsiveContainer width="100%" height={280}>
      <BarChart data={data} barGap={4}>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 20%)" />
        <XAxis dataKey="sector" tick={{ fill: "hsl(220 10% 55%)", fontSize: 12 }} axisLine={false} tickLine={false} />
        <YAxis tick={{ fill: "hsl(220 10% 55%)", fontSize: 12 }} axisLine={false} tickLine={false} />
        <Tooltip
          contentStyle={{ background: "hsl(220 18% 13%)", border: "1px solid hsl(220 15% 20%)", borderRadius: 8, color: "hsl(180 10% 92%)" }}
        />
        <Legend wrapperStyle={{ fontSize: 12, color: "hsl(220 10% 55%)" }} />
        <Bar dataKey="current" name="Current" fill="hsl(0 65% 55%)" radius={[4, 4, 0, 0]} />
        <Bar dataKey="withCapture" name="With Capture" fill="hsl(160 60% 45%)" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  </div>
);

export default EmissionsChart;
