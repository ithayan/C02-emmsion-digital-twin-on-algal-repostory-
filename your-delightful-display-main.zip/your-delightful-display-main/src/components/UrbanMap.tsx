import { MapPin } from "lucide-react";

interface UrbanMapProps {
  zones: { name: string; x: string; y: string; level: "high" | "medium" | "low" }[];
  cityName: string;
}

const levelColors: Record<string, string> = {
  high: "text-destructive",
  medium: "text-chart-3",
  low: "text-primary",
};

const levelBg: Record<string, string> = {
  high: "bg-destructive/20",
  medium: "bg-chart-3/20",
  low: "bg-primary/20",
};

const UrbanMap = ({ zones, cityName }: UrbanMapProps) => (
  <div className="rounded-xl border border-border bg-card p-5">
    <h3 className="mb-1 text-sm font-semibold text-foreground">{cityName} CO₂ Density Map</h3>
    <p className="mb-4 text-xs text-muted-foreground">Real-time emission hotspots across the city</p>
    <div className="relative h-[300px] rounded-lg bg-secondary/50 overflow-hidden">
      <div className="absolute inset-0 opacity-20" style={{
        backgroundImage: "linear-gradient(hsl(160 60% 45% / 0.3) 1px, transparent 1px), linear-gradient(90deg, hsl(160 60% 45% / 0.3) 1px, transparent 1px)",
        backgroundSize: "40px 40px"
      }} />
      
      {zones.map((zone) => (
        <div
          key={zone.name}
          className="absolute flex flex-col items-center transition-transform hover:scale-110 cursor-pointer"
          style={{ left: zone.x, top: zone.y, transform: "translate(-50%, -50%)" }}
        >
          <div className={`rounded-full p-1.5 ${levelBg[zone.level]}`}>
            <MapPin className={`h-4 w-4 ${levelColors[zone.level]}`} />
          </div>
          <span className="mt-1 whitespace-nowrap text-[10px] font-medium text-muted-foreground">{zone.name}</span>
        </div>
      ))}

      <div className="absolute bottom-3 right-3 flex gap-3 rounded-lg bg-card/80 px-3 py-2 backdrop-blur-sm border border-border">
        <div className="flex items-center gap-1.5">
          <div className="h-2.5 w-2.5 rounded-full bg-destructive" />
          <span className="text-[10px] text-muted-foreground">High</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="h-2.5 w-2.5 rounded-full" style={{ background: "hsl(40 80% 55%)" }} />
          <span className="text-[10px] text-muted-foreground">Medium</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="h-2.5 w-2.5 rounded-full bg-primary" />
          <span className="text-[10px] text-muted-foreground">Low</span>
        </div>
      </div>
    </div>
  </div>
);

export default UrbanMap;
