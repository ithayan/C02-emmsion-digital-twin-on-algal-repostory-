import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

interface AirQualityChartProps {
  data: { month: string; aqi: number | null; predicted: number }[];
}

const AirQualityChart = ({ data }: AirQualityChartProps) => (
  <div className="rounded-xl border border-border bg-card p-5">
    <h3 className="mb-1 text-sm font-semibold text-foreground">Air Quality Index Prediction</h3>
    <p className="mb-4 text-xs text-muted-foreground">Actual AQI vs. predicted with interventions</p>
    <ResponsiveContainer width="100%" height={280}>
      <AreaChart data={data}>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 20%)" />
        <XAxis dataKey="month" tick={{ fill: "hsl(220 10% 55%)", fontSize: 12 }} axisLine={false} tickLine={false} />
        <YAxis tick={{ fill: "hsl(220 10% 55%)", fontSize: 12 }} axisLine={false} tickLine={false} />
        <Tooltip
          contentStyle={{ background: "hsl(220 18% 13%)", border: "1px solid hsl(220 15% 20%)", borderRadius: 8, color: "hsl(180 10% 92%)" }}
        />
        <Area type="monotone" dataKey="aqi" name="Actual AQI" stroke="hsl(40 80% 55%)" fill="hsl(40 80% 55% / 0.1)" strokeWidth={2} connectNulls={false} />
        <Area type="monotone" dataKey="predicted" name="Predicted AQI" stroke="hsl(160 60% 45%)" fill="hsl(160 60% 45% / 0.1)" strokeWidth={2} strokeDasharray="6 3" />
      </AreaChart>
    </ResponsiveContainer>
  </div>
);

export default AirQualityChart;
