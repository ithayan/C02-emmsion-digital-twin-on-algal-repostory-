import { useState } from "react";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Play, RotateCcw, Settings2 } from "lucide-react";

const SimulationPanel = () => {
  const [dac, setDac] = useState([30]);
  const [biochar, setBiochar] = useState([50]);
  const [greenInfra, setGreenInfra] = useState([40]);
  const [evAdoption, setEvAdoption] = useState([25]);

  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="mb-4 flex items-center gap-2">
        <Settings2 className="h-4 w-4 text-primary" />
        <h3 className="text-sm font-semibold text-foreground">Simulation Controls</h3>
      </div>

      <div className="space-y-5">
        <div>
          <div className="mb-2 flex justify-between">
            <span className="text-xs text-muted-foreground">Direct Air Capture Units</span>
            <span className="font-mono text-xs text-primary">{dac[0]}%</span>
          </div>
          <Slider value={dac} onValueChange={setDac} max={100} step={5} className="[&_[role=slider]]:bg-primary [&_[role=slider]]:border-primary" />
        </div>

        <div>
          <div className="mb-2 flex justify-between">
            <span className="text-xs text-muted-foreground">Biochar Deployment</span>
            <span className="font-mono text-xs text-primary">{biochar[0]}%</span>
          </div>
          <Slider value={biochar} onValueChange={setBiochar} max={100} step={5} className="[&_[role=slider]]:bg-primary [&_[role=slider]]:border-primary" />
        </div>

        <div>
          <div className="mb-2 flex justify-between">
            <span className="text-xs text-muted-foreground">Green Infrastructure</span>
            <span className="font-mono text-xs text-primary">{greenInfra[0]}%</span>
          </div>
          <Slider value={greenInfra} onValueChange={setGreenInfra} max={100} step={5} className="[&_[role=slider]]:bg-primary [&_[role=slider]]:border-primary" />
        </div>

        <div>
          <div className="mb-2 flex justify-between">
            <span className="text-xs text-muted-foreground">EV Adoption Rate</span>
            <span className="font-mono text-xs text-primary">{evAdoption[0]}%</span>
          </div>
          <Slider value={evAdoption} onValueChange={setEvAdoption} max={100} step={5} className="[&_[role=slider]]:bg-primary [&_[role=slider]]:border-primary" />
        </div>
      </div>

      <div className="mt-6 flex gap-2">
        <Button className="flex-1 gradient-green text-primary-foreground font-semibold hover:opacity-90">
          <Play className="mr-1.5 h-4 w-4" />
          Run Simulation
        </Button>
        <Button variant="outline" size="icon" className="border-border text-muted-foreground hover:text-foreground">
          <RotateCcw className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
};

export default SimulationPanel;
